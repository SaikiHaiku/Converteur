def convert(input_path, output_path, output_format):
    print(f"[Text] Conversion de {input_path} vers {output_path} en {output_format}")
    # TODO: Implémenter les conversions texte ici