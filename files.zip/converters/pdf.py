def convert(input_path, output_path, output_format):
    print(f"[PDF] Conversion de {input_path} vers {output_path} en {output_format}")
    # TODO: Utiliser PyPDF2, pdfplumber etc.